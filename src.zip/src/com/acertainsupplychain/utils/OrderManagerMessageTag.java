package com.acertainsupplychain.utils;

public enum OrderManagerMessageTag {
    GETORDER, REGISTERORDER
}
