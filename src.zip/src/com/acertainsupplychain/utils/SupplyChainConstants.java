package com.acertainsupplychain.utils;

public final class SupplyChainConstants {
    public static final String KEY_ITEMS = "items";
    public static final String KEY_ORDERMANAGER = "ordermanager";
    public static final String KEY_SUPPLIERS = "suppliers";
    public static final String SUPPLIER_ID_SPLIT_REGEX = ",";
    public static final String SUPPLIER_ITEM_SPLIT_REGEX = ":";
    public static final String SUPPLIER_SERV_SPLIT_REGEX = ";";
}
