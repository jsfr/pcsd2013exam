package com.acertainsupplychain.utils;

public enum ItemSupplierMessageTag {
    EXECUTESTEP, GETORDERS
}
